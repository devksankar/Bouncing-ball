let r, g, b, x, y, xspeed, yspeed, soundFile;
let animate = false;
const radius = 25;

function preload() {
  soundFormats('mp3', 'ogg');
  soundFile = loadSound('assets/beatbox.ogg');
}

function setup() {
  createCanvas(640, 360);
  
  x = width / 2;
  y = height / 2;
  xspeed = random(3, 7);
  yspeed = random(3, 7);
  r = random(255);
  g = random(255);
  b = random(255);
}

function mousePressed() {
  animate = !animate;
  soundFile.stop();
}

function draw() {
  background(0);
  noStroke();
  fill(r, g, b);
  circle(x, y, radius * 2);
  
  if (animate) {
    x += xspeed;
    y += yspeed;
  }
  
  if (x <= radius || x >= width - radius) {
    xspeed = xspeed * -1;
    r = random(255);
    g = random(255);
    b = random(255);
    soundFile.play();
  }
  
  if (y <= radius || y >= height - radius) {
    yspeed = yspeed * -1;
    r = random(255);
    g = random(255);
    b = random(255);
    soundFile.play();
  }
}
